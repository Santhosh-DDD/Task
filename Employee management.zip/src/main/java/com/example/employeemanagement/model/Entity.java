package com.example.employeemanagement.model;

public @interface Entity {

}

public @interface Id{
	
}
