package com.example.employeemanagement.service;

import com.example.employeemanagement.model.Employee;
import com.example.employeemanagement.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;
    
    public Employee addEmployee_1(Employee employee) {
        return employeeRepository.save(employee);
    }


    public Optional<Employee> getEmployeeById_1(Long id) {
        return employeeRepository.findById(id);
    }

   

    public Employee updateEmployee_1(Long id, Employee employeeDetails) {
        Employee employee = employeeRepository.findById(id).orElseThrow();
        employee.setName(employeeDetails.getName());
        employee.setDesignation(employeeDetails.getDesignation());
        employee.setDepartment(employeeDetails.getDepartment());
        return employeeRepository.save(employee);
    }
    
    public List<Employee> getAllEmployees_1() {
        return employeeRepository.findAll();
    }

    public void deleteEmployee_1(Long id) {
        employeeRepository.deleteById(id);
    }
}
