package com.example.employeemanagement.exception;

public class EmployeeException 
{
     public static void IDnotfound()
     {
    	 System.out.println("ID not found exception");
     }
}
